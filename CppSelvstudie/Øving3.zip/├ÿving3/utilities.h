#pragma once
#include "std_lib_facilities.h"

int randomWithLimits(int upper, int lower);