import matplotlib.pyplot as plt

u = [2,3,1]
v = [2,3,9]
q = [-2,0,1]

fig = plt.figure()
ax = plt.axes(projection = "3d")
ax.set_xlim([-1,10])
ax.set_xlim([-10,10])
ax.set_xlim([0,10])
