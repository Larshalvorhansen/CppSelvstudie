
// This is example code from Chapter 2.2 "The classic first program" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup

// keep_window_open() added for TDT4102, excercise 0

// This program outputs the message "Hello, World!" to the monitor

#include "std_lib_facilities.h"

int main(){
	int choice = -1;
    while (choice != 0){
        cout << "0) Avslutt \n"
             << "1) testCallByValue\n";
        cout << "Angi valg (0-11): ";

        cin >> choice;
        cout << '\n';

        switch (choice){
			case 0:
				break;
			case 1:
				break;
			case 2:
				break;
		}
	}
}

/* Medlemsfunksjoner av public kan bli benyttet utenfor klassen
Private sine medlemsfunkjsoner kan ikke bli benyttet utenfor klassen
Protected kan haller ikke bli benyttet utenforklassen med untak av avede klasser
 */