#pragma once
#include "std_lib_facilities.h"
#include "Emoji.h"

class Face : Emoji{
private:COO
    Point c ;
    int r = 0;
public:
    Face(/* args */);
    ~Face();
};

Face::Face(/* args */)
{
}

Face::~Face()
{
}
