#include "animal.h"

string Animal::toString(string name, int age){
    return("Animal: " + name + to_string(age));
}

string Cat::toString(string name, int age){
    Animal cat(name,age);
    return("Cat: " + name + to_string(age));
}

string Dog::toString(string name, int age){
    Animal dog(name,age);
    return("Dog: " + name + to_string(age));
}

void testAnimal(){
    Cat::toString("gato",4);
    Dog::toString("perro",3);
}