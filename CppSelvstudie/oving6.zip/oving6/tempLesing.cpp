#include "tempLesing.h"

istream& operator>>(istream& is, Temp& s){
};

vector Temps::readTemps(string filnavn){
    while(is >> min >> max){
        ifstream inFile {"temperatures.txt"};
        while(getline(inFile, line)){
            string ord1;
            string ord2;
            for(char c in line){
                while (char c != ' '){
                    ord1 += c;
                }
                ord2 += c;
            }
            data.insert({static_cast<float>(ord1),static_cast<float>(ord1)});
            cout << ord1 << " " << ord2 << endl;
        }
    }
}

vector Temps::tempStats(){
    float maks = 0.0;
    float min = 0.0;
    int indeksM;
    for(int i=0; i < data.size(); i++){
        if(data[i][1] > maks){
            maks = data[i][1];
            indeksM = i;
        }
    }
    for(int i=0; i < data.size(); i++){
        if(data[i][1] < min){
            min = data[i][1];
            indeksm = i;
        }
    }
    cout << "Dag " << i << " hadde høyest temperatur. Da var temperaturen " << maks << endl;
    cout << "Dag " << i << " hadde lavest temperatur. Da var temperaturen " << min << endl;
}