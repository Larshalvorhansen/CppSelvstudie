#pragma once
#include "std_lib_facilities.h"

class Temps{
    vector<float,float> data;
    private:
        float max;
        float min;
    public:
        friend istream& operator>>(istream& is, Temps& t);
        vector readTemps(string filnavn);
        vector tempStats();
};