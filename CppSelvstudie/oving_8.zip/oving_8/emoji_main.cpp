#include "AnimationWindow.h"
#include "Emoji.h"

// Definer størrelse på vindu og emoji
constexpr int xmax = 1000;
constexpr int ymax = 600;
constexpr int emojiRadius = 50;

int main()
{
	const Point tl{100, 100};
	const string win_label{"Emoji factory"};
	AnimationWindow win{tl.x, tl.y, xmax, ymax, win_label};

	/* TODO: 
	 *  - initialiser emojiene
	 *  - Tegn emojiene til vinduet
	 **/
	
	win.draw_circle({23,40} ,100, Color::blue);//hva slags type er centre?

	win.wait_for_close();
}