#include "Person.h"
#include "Car.h"

bool Person::hasAvalibleSeats(unique_ptr<string> car){
    if(Car::hasFreeSeats() = true && unique_ptr<string> car =! nullptr){
        return true;
    }
    else{
        return false;
    }
}