#include "BlackJack.h"
#include "Card.h"

bool BlackJack::isAce(Card c){
    if(rankToString(static_cast<rank>(c))=="ace"){return(true);}
    else{return(false);}
}

int BlackJack::getCardValue(Card c){
    string valueS = rankToString(static_cast<rank>(c));
    int value = 0;
    if(valueS == "two"){value = 2;}
    if(valueS == "three"){value = 3;}
    if(valueS == "four"){value = 4;}
    if(valueS == "five"){value = 5;}
    if(valueS == "six"){value = 6;}
    if(valueS == "seven"){value = 7;}
    if(valueS == "eight"){value = 8;}
    if(valueS == "nine"){value = 9;}
    if(valueS == "ten"){value = 10;}
    if(valueS == "jack"){value = 11;}
    if(valueS == "queen"){value = 12;}
    if(valueS == "king"){value = 13;}
    if(valueS == "ace"){value = 11;}
    return(value);
}