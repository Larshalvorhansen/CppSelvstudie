#include "Block.h"

// TASK
BlockType Block::getBlockType(int n) const
{
    // BEGIN: 1a
    if (n == 8)
    {
        return BlockType::Stone;
    }
    if (n == 62)
    {
        return BlockType::Grass;
    }
    if (n == 93)
    {
        return BlockType::Gold;
    }
    if (n == 0)
    {
        return BlockType::None;
    }
    // END: 1a
}

// TASK
void Block::draw(AnimationWindow &win, Point upperLeftCorner) const
{
    // BEGIN: 1b

    Block::Block() : posisjon(sf::V()),
                     bredde(30.0f),
                     høyde(15.0f),
                     farge(sf::Farge())
    {}

    Block::Block(float startX, float startY) : bredde(40.0f),
                                               høyde(20.0f)
    {
        farge = sf::Farge::White;
        Posisjon.y = startY;
        Posisjon.x = startX;

        block.setPosisjon(Posisjon);
        block.setFyllFarge(farge);
        block.setStørrelse(sf::V2(bredde, høyde));
    }

    (void)win; // (These lines do nothing, but avoid "unused variable" warnings in the handout code)
    (void)upperLeftCorner;

    // END: 1b
}